package com.ciklum.ciklumbackendTarea.exceptions;

public class SesionNoEncontradaException extends RuntimeException {
}
