package com.ciklum.ciklumbackendTarea.exceptions;

public class PlanNoEncontradoException extends RuntimeException {
}
